﻿using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge.Data
{
    public class UserDetails
    {
        public static Users GetUserDetails(int userid)
        {
            Users user = null;
            List<Users> customerlist = new List<Users>();
            using (SqlConnection conn = new SqlConnection(("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")))
            {
                conn.Open();
                //string sql = @"SELECT Userid, UserName, Password, Firstname from Users WHERE UserId = '" + userid + "'";
                string sql = @"SELECT UserID,Name from Users WHERE UserId = '" + userid + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    user = new Users()
                    {
                        Userid = (int)reader["UserId"],
                        UserName = (string)reader["Name"],
                        //Password = (string)reader["Password"],
                        //Firstname = (string)reader["Firstname"]
                    };
                }
            }
            return user;
        }
    }
}
