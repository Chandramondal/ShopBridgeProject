﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;

using System.Web;
using RestSharp;

namespace ShopBridge.Data
{
    public class SessionManagement
    {        //Creating Session
        public static string CreateSession(int customer_id)
        {
            string sessionId = Guid.NewGuid().ToString();
            using (SqlConnection conn = new SqlConnection("Server=.; Database=ShoppingCartT4; Integrated Security=true"))
            {
                conn.Open();
                string sql = @"UPDATE Customer SET session_id = '" + sessionId + "'" + " WHERE customer_id =" + customer_id;
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }
            return sessionId;
        }


        //Destroying Session
        //public static void RemoveSession(string sessionId)
        //{
        //    foreach (string key in Microsoft.AspNetCore.Http.HttpContext.Request.Cookies.Keys)
        //    {
        //        HttpCookie c = Microsoft.AspNetCore.Http.HttpContext.Request.Cookies[key];
        //        c.Expires = DateTime.Now.AddMonths(-1);
        //        Microsoft.AspNetCore.Http.HttpContext.Response.Cookies(c);
        //    }
        //    using (SqlConnection conn = new SqlConnection("Server=.; Database=ShoppingCartT4; Integrated Security=true"))
        //    {
        //        conn.Open();
        //        string sql = @"UPDATE Customer SET session_id = NULL WHERE session_id = '" + sessionId + "'";
        //        SqlCommand cmd = new SqlCommand(sql, conn);
        //        cmd.ExecuteNonQuery();
        //    }
        //}

    }
}
