﻿using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge.Data
{
    public class ProductDetails
    {
        public static List<ProductItem> Details()
        {
            List<ProductItem> ProductList = new List<ProductItem>();
            using (SqlConnection conn = new SqlConnection(("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")))
            {
                conn.Open();
                string sql = @"SELECT * from Product";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    ProductItem product = new ProductItem()
                    {
                        ProductID = (int)reader["ProductID"],
                        ProductName = (string)reader["ProductName"],
                        ProductDesc = (string)reader["ProductDesc"],
                        ProductPrice = (int)reader["ProductPrice"],
                        ProductImage = (string)reader["ProductImage"]
                    };
                    ProductList.Add(product);

                }
            }
            return ProductList;



        }
    }
}
