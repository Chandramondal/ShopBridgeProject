﻿using Microsoft.Extensions.Logging;
using Moq;
using ShopBridge.Controllers;
using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace ShopBridge.UnitTest
{
    public class HomeControllerTest
    {
        HomeController homeController;
        public HomeControllerTest()
        {
            homeController = new HomeController();
        }

        [Fact]
        public void IndexTest()
        {
            homeController.Index();

        }
        [Fact]
        public void ProcessLoginTest()
        {
            homeController.ProcessLogin();
        }

        [Fact]
        public void RegisterNewCustomerTest()
        {
            homeController.RegisterNewCustomer();
        }
        [Fact]
        public void SucessfulLoginTest()
        {
            Users users = new Users();
            users.UserName = "abc";
            users.Password = "abc";
            users.Userid = 1;
            homeController.SucessfulLogin(users);
        }
    }
}
