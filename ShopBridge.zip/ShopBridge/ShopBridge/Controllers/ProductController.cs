﻿using Microsoft.AspNetCore.Mvc;
using ShopBridge.Data;
using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Windows.Web.Http;

namespace ShopBridge.Controllers
{
    public class ProductController : Controller
    {
        static List<PurchaseItems> allitems;
        public ActionResult Purchase(string customer_id)
        {
            List<ProductItem> returnListofitems = ProductDetails.Details();
            ViewBag.Products = returnListofitems;
            return View(returnListofitems);
        }
        public IActionResult AddtoCart()
        {
            string Userid = Request.Cookies["UserId"];
            allitems = new List<PurchaseItems>();
            using (SqlConnection conn = new SqlConnection(("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")))
            {
                conn.Open();
                string sql = @"INSERT INTO Purchaseitem (UserID,ProductId,Purchasetime) " +
                                 "values (" + Userid + "," + ",'" + "','" + DateTime.Now.ToString("yyyy/MM/dd") + "');";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    PurchaseItems p = new PurchaseItems()
                    {
                        ProductID = (int)reader["ProductID"],
                        ProductDesc = (string)reader["ProductDesc"],
                        ProductPrice = (int)reader["ProductPrice"],

                       

                };
                    allitems.Add(p);
                    ViewBag.Item = (int)reader["Count"];
                }
            }
            return View("Purchase", allitems);
        }
        public IActionResult CheckOut()
        {

            HttpCookieCollection itemcookies = (HttpCookieCollection)Request.Cookies;
            string Userid = Request.Cookies["UserId"];

            Dictionary<string, string> kV = new Dictionary<string, string>();
            List<PurchaseItems> Purchaselist = new List<PurchaseItems>();
            using (SqlConnection conn = new SqlConnection(("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")))
            {
                conn.Open();
                string sql = @"select Purchaseitem, ProductId, Purchasetime, pro_desc, pro_image, count(i.ProductId) as count from Purchaseitem i join Product p on i.ProductId = p.ProductID where userId ='" + Userid + "' group by i.ProductID, PurchaseItem, ProductName";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    PurchaseItems singleitem = new PurchaseItems();
                    singleitem.PurchaseTime = (DateTime)reader["PurchaseTime"];
                    singleitem.ProductID = (int)reader["ProductID"];
                    singleitem.ProductDesc = (string)reader["ProductDesc"];
                    singleitem.ProductImage = (string)reader["ProductImage"];
                    singleitem.ProductPrice = (int)reader["ProductPrice"];
                    singleitem.count = (int)reader["count"];
                    Purchaselist.Add(singleitem);
                }
            }
            return RedirectToAction("AllPurchaseItem", "Purchase", null);

        }

        public IActionResult DeleteItemFromCart()
        {
          
            HttpCookieCollection itemcookies = (HttpCookieCollection)Request.Cookies;
            string Userid = Request.Cookies["UserId"];

            Dictionary<string, string> kV = new Dictionary<string, string>();
            List<PurchaseItems> Purchaselist = new List<PurchaseItems>();
            using (SqlConnection conn = new SqlConnection(("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")))
            {
                conn.Open();
                string sql = @"delete from Purchaseitem where userId ='" + Userid + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                ViewBag.Item = 0;
            }

            return View("Purchase", Purchaselist);
        }
    }
}
