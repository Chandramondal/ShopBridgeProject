﻿using Microsoft.AspNetCore.Mvc;
using ShopBridge.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge.Controllers
{
    public class PurchaseController : Controller
    {
        public IActionResult AllPurchaseItem()
        {
            List<PurchaseItems> Purchaselist = new List<PurchaseItems>();
            using (SqlConnection conn = new SqlConnection(("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False")))
            {
                conn.Open();
                string sql = @"select Purchaseitem, ProductId, ProductDesc, ProductPrice, ProductImage, count(i.ProductId) as count from Purchaseitem";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    PurchaseItems singleitem = new PurchaseItems();
                    singleitem.PurchaseTime = (DateTime)reader["PurchaseTime"];
                    singleitem.ProductID = (int)reader["ProductID"];
                    singleitem.ProductDesc = (string)reader["ProductDesc"];
                    singleitem.ProductImage = (string)reader["ProductImage"];
                    singleitem.ProductPrice = (int)reader["ProductPrice"];
                    singleitem.count = (int)reader["count"];
                    Purchaselist.Add(singleitem);
                }
            }
            return View(Purchaselist);
        }
        public IActionResult LogOut()
        {
            return RedirectToAction("ProcessLogin", "Home", null);
        }
        public IActionResult MakePaymenet()
        {
            return View();
        }
    }
}
