﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShopBridge.Models
{
    public class ProductItemList
    {
        public int ProductID { get; set; }
        public string ProductType { get; set; }
        public string ProductDesc { get; set; }

        public int ProductPrice { get; set; }

        public string ProductImage { get; set; }
        public int count { get; set; }
        public DateTime PurchaseTime { get; set; }
    }
}
